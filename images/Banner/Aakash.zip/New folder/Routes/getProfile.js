const {Router}=require("express");
const { authentication } = require("../Middleware/authentication");
const { SignupModel } = require("../Model/signup.model");


const app=Router();


app.get("/getProfile",authentication,async(req,res)=>{
    const {userId}=req.body;
    const userData=await SignupModel.find({_id:userId},{_id:0,email:1,name:1,createdAt:1,updatedAt:1});
    res.status(200).send(userData);
})


module.exports=app;