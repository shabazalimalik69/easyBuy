const { Router } = require("express");
const { SignupModel } = require("../Model/signup.model");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const dotenv = require("dotenv").config();

const app = Router();

app.post("/register", async (req, res) => {
  const { name, email, password, userId } = req.body;

  try {
    const auth_user = await SignupModel.findOne({ email });
   

    if (auth_user) {
      return res.status(403).send({ msg: "User are already exists" });
    } else {
      bcrypt.hash(password, 5, async function (err, hash) {
        if (err) {
          return res.status(501).send(err);
        }
          const new_authUser = new SignupModel({
            name,
            email,
            password: hash,
            userId,
          });

          await new_authUser.save();
          return res.status(201).send({ msg: "Signup Successfully" });

      });
    }
  } catch (err) {
    return res.status(500).send(err);
  }
});

app.post("/login", async (req, res) => {
  const { name,email, password } = req.body;

  const validUser = await SignupModel.findOne({ email });
  if (validUser) {
    const userId = validUser._id;
    const hash = validUser.password;
    const name = validUser.name;
    const email=validUser.email;

    try {
      await bcrypt.compare(password, hash, async function (err, result) {
        if (err) {
          return res.status(500).send(err);
        }
        if (result) {
          const token = jwt.sign({ userId }, process.env.SECRET_KEY);
          return res
            .status(201)
            .send({
              msg: "Login Successful",
              token: token,
            //   name: name,
            //   email:email,
              userId,
            });
        } else {
          return res.status(401).send({ msg: "Login failed!" });
        }
      });
    } catch (err) {
      return res.status(401).send({ msg: "Login failed!" });
    }
  } else {
    return res.status(401).send({ msg: "Login failed!" });
  }
});

module.exports = app;
