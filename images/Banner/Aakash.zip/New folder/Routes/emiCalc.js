const {Router}=require("express");
const { authentication } = require("../Middleware/authentication");
const { EmiModel } = require("../Model/emiCalc.model");


const app=Router();

app.post("/calculateEMI",authentication,async(req,res)=>{
    const {Loan_amount,Annual_Interest_rate,Tenure_in_months,userId}=req.body;
    const EMI=Loan_amount*Annual_Interest_rate*( 1 + Annual_Interest_rate )*Tenure_in_months / ( ( 1 + Annual_Interest_rate )*Tenure_in_months - 1 ); 
     try{
        const Emidata = await EmiModel({Loan_amount,Annual_Interest_rate,Tenure_in_months,userId})
        await Emidata.save();
        res.status(201).send({"msg":"EMI Created","EMI is:":EMI})
     }
     catch(err){
        res.status(500).send(err)
     }
})



module.exports=app;